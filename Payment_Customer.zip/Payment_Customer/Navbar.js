
import React from "react"

 export default function Navbar() {
     return (
         <nav>
             <h3>YYC Cars</h3>
        
         </nav>
     )
 } 
